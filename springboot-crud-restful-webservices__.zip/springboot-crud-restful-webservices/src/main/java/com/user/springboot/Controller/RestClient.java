package com.user.springboot.Controller;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.user.springboot.entity.User;

public class RestClient {
	
	private static final String GET_USER_BY_ID_API = "http://localhost:8080/api/users/{id}";
	private static final String CREATE_USER_API = "http://localhost:8080/api/users";
	private static final String UPDATE_USER_API = "http://localhost:8080/api/users/{id}";
	private static final String DELETE_USER_API = "http://localhost:8080/api/users/{id}";

	static RestTemplate restTemplate=new RestTemplate();
	public static void main(String[] args) {
		callGetUserByIdAPI();
		callCreateUserAPI();
		callUpdateUserAPI();
		callDeleteAPI();
	}
		
	private static void callGetUserByIdAPI() {
		Map<String, Integer> param=new HashMap<>();
		param.put("id", 2);
		
		User user=restTemplate.getForObject(GET_USER_BY_ID_API, User.class, param);
		System.out.println(user.getFirstName());
		System.out.println(user.getLastName());
		System.out.println(user.getEmail());
		
	}
	
	private static void callCreateUserAPI() {
		User user=new User("Shivani", "kshatriya", "shivanik@gmail.com");
		ResponseEntity<User> user2=restTemplate.postForEntity(CREATE_USER_API, user, User.class);
		System.out.println(user2.getBody());
	}
	
	private static void callUpdateUserAPI() {
		Map<String, Integer> param=new HashMap<>();
		param.put("id", 2);
		User updateUser=new User("xyz", "abc", "abc@gmail.com");
		restTemplate.put(UPDATE_USER_API, updateUser, param);
		}
	
	private static void callDeleteAPI() {
		Map<String, Integer> param=new HashMap<>();
		param.put("id", 2);
		restTemplate.delete(DELETE_USER_API, param);
	}

}
